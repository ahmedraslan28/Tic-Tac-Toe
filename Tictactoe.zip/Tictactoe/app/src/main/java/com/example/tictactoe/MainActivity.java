    package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

    public class MainActivity extends AppCompatActivity implements View.OnClickListener {
        private TextView playeronescore , playertwoscore , playerstatus;
        private Button [] buttons = new Button[9];
        private  Button resetgame;
            private  int playeronescorecounter, playertwoscorecounter ,roundcounter;
            boolean activeplayer;
                int [] gamestate = {2,2,2,2,2,2,2,2,2};

                int [][] winingpostions = {
                        {0,1,2},{3,4,5},{6,7,8},
                        {0,3,6},{1,4,7},{2,5,8},
                        {0,4,8},{2,4,6}
                };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playeronescore = (TextView) findViewById(R.id.playeroneScore);
        playertwoscore = (TextView)  findViewById(R.id.playertwoscore);
        playerstatus = (TextView) findViewById(R.id.playeronestatus);

        resetgame = (Button) findViewById(R.id.resetgame);
        for (int i=0 ;i < buttons.length;i++)
        {
            String button_id = "button_" + i;
            int resourseID = getResources().getIdentifier(button_id,"id",getPackageName());
            buttons[i] =(Button)  findViewById(resourseID);
            buttons[i].setOnClickListener(this);

        }
        roundcounter =0;
        playeronescorecounter=0;
        playertwoscorecounter =0;
        activeplayer=true;



    }

        @Override
        public void onClick(View v) {
            if (!((Button) v).getText().toString().equals("")) return;

            String buttonid=v.getResources().getResourceEntryName(v.getId());
            int gamestatepointer = Integer.parseInt(buttonid.substring(buttonid.length()-1,buttonid.length()));

            if(activeplayer)
            {
                ((Button) v ).setText("X");
                ((Button)v).setTextColor(Color.parseColor("#FADA39"));
                gamestate[gamestatepointer] = 0;

            }
            else

            {
                ((Button) v ).setText("O");
                ((Button)v).setTextColor(Color.parseColor("#848484"));
                gamestate[gamestatepointer] = 1;

            }
            roundcounter++;
if (checkwinner())
{
if (activeplayer)
{
    playeronescorecounter++;
    updatescore();
    Toast.makeText(this,"First Player is the Winner ! " ,Toast.LENGTH_SHORT).show();
    resetagain();


}
else
{
    playertwoscorecounter++;
    updatescore();
    Toast.makeText(this,"Second Player is the Winner ! " ,Toast.LENGTH_SHORT).show();
    resetagain();

}
}
else if (roundcounter==9)
{
    resetagain();
    Toast.makeText(this," There is No winner !  " ,Toast.LENGTH_SHORT).show();
}
else
{
    activeplayer=!activeplayer;
}


        if (playeronescorecounter > playertwoscorecounter)
        {
            playerstatus.setText("First Player is the Winner ! ");
        }
        else if (playeronescorecounter < playertwoscorecounter)
        {
            playerstatus.setText("Second Player is the Winner ! ");

        }
        else
        {
            playerstatus.setText("");

        }
resetgame.setOnClickListener(new View.OnClickListener(){
    @Override
    public void onClick(View v) {
        resetagain();
        playeronescorecounter=0;
        playertwoscorecounter=0;
        playerstatus.setText("");
        updatescore();
    }
});

        }
        public  boolean checkwinner()
        {
            boolean winner =false;
            for (int [] winningpostion : winingpostions)
            {
                if (gamestate[winningpostion[0]]==gamestate[winningpostion[1]]
                        &&gamestate[winningpostion[1]] == gamestate[winningpostion[2]] && gamestate[winningpostion[0]]!=2)
                {
                    winner=true;
                }
            }
            return  winner;

        }
        public  void updatescore()
        {
            playeronescore.setText(Integer.toString(playeronescorecounter));
            playertwoscore.setText(Integer.toString(playertwoscorecounter));
        }

        public  void resetagain()
        {
            roundcounter=0;
            activeplayer=true;
            for (int i=0; i < buttons.length;i++)
            {
                gamestate[i] = 2;
buttons[i].setText("");
            }

        }
    }
